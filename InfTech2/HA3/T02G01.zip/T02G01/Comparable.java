
public interface Comparable {
		int compareTo(Comparable other);
}
