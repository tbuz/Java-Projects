
public interface Comparable {
    public int compareTo(Matrix andereMatrix);
}